<?php get_header() ?>
    <h1>Hello WordPress !</h1>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Non deleniti molestiae soluta iure possimus facilis deserunt commodi quas ipsa assumenda labore aliquid, enim laudantium, mollitia tempora, explicabo nisi necessitatibus delectus.</p>
    <h2>Les pages</h2>
    <?php 
   $query = new WP_Query([
    "post_type"  => "page",
    "posts_per_page" => 4,
    "orderby"  => "menu_order",
    "order"  => "ASC" // DESC
    ] ); 
   if ( $query->have_posts() ) // si il y a des résultats dans la pile 
   {
      while( $query->have_posts() )
      {
         $query->the_post(); // enlever le résultat de la pile 
         ?>
         <a href="<?php the_permalink() ?>"><?php  the_title() ?></a><br>
      
        <?php
      } 
   } 
 ?>
 <h2>Les actualité</h2>
 <?php 
   $query = new WP_Query([
    "post_type"  => "post",
    "posts_per_page" => 4,
    "orderby"  => "publish_date",
    "order"  => "DESC" // DESC
    ] ); 
   if ( $query->have_posts() ) // si il y a des résultats dans la pile 
   {
      while( $query->have_posts() )
      {
         $query->the_post(); // enlever le résultat de la pile 
        ?>
        <a href="<?php the_permalink() ?>"><?php the_post_thumbnail('thumbnail') ?></a>
         <a href="<?php the_permalink() ?>"><?php  the_title() ?></a><br>
        <?php
      } 
   } 
 ?>
 <h2>Les Produits</h2>
 <?php 
   $query = new WP_Query([
    "post_type"  => "produit",
    "posts_per_page" => 4,
    ] ); 
   if ( $query->have_posts() ) // si il y a des résultats dans la pile 
   {
      while( $query->have_posts() )
      {
         $query->the_post(); // enlever le résultat de la pile 
        ?>
        <a href="<?php the_permalink() ?>"><?php the_post_thumbnail('thumbnail') ?></a>
         <a href="<?php the_permalink() ?>"><?php  the_title() ?></a><br>
        <?php
      } 
   } 
 ?>
<?php get_footer() ?>