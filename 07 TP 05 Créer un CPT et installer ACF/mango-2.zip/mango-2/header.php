<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Mon site</title>
    <?php
        $theme_url = get_stylesheet_directory_uri(); 
    ?>
    <link rel="stylesheet" href="<?=$theme_url?>/style.css">
    <?php wp_head() ?>
</head>
<body>
    <header>
        ici le header...
    </header>