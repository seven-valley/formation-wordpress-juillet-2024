<?php 
   get_header(); 
   while(have_posts()):
 the_post();
 ?>
   <h1><?php the_title() ?></h1>
   <h2><?php the_field('sous_titre')?></h2>
   <p> modele produit 2</p>
   <p><?php the_content() ?></p>
 <?php
   endwhile;
   get_footer(); 
 ?>