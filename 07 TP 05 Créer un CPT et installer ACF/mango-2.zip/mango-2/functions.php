<?php
// ------------------------------------------------ 
// 1 – Les Constantes 
// -----------------------------------------------
define('THEMEROOT', get_stylesheet_directory_uri());
define('IMG', THEMEROOT . '/img');
define('JS', THEMEROOT . '/js');
define('CSS', THEMEROOT . '/css');
// ----------------------------------------------


// ------------------------------------------------------- 
// 2 & 3 – Activer les images mise en avant ET les menus
// -------------------------------------------------------
function my_theme_setup()
{
   add_theme_support('post-thumbnails'); // img mise en avant
   register_nav_menus([
      // ['identifiant' => 'Nom dans le Back Office Wordpress' ]
      'menu_haut' => 'Menu Haut de Page',
      'menu_bas'  => 'Menu Bas de Page'
   ]);
}
add_action('after_setup_theme', 'my_theme_setup'); // le crochet 
// ------------------------------------------------ 

// ------------------------------------------------ 
// 6 – Activer les Custom Post 
// -----------------------------------------------


function my_produit_custom_post()
{
   $tab_labels = [
      'name' => 'Produits',
      'singular_name' => 'Produit',
      'menu_name'  => 'Produit',
      'all_items'    => 'Tous les produits',
      'view_item'   => 'Voir tous les produits',
      'add_new_item'  => 'Ajouter un nouveau produit',
      'add_new'    => 'Ajouter',
      'edit_item'   => 'Editer un produit',
      'update_item'   => 'Modifier un produit ',
      'search_items'  => 'Rechercher un produit'
   ];

   register_post_type(
      'produit',
      [
         'label'  => 'Produits',

         'public'   => true,

         'show_in_rest' => true,
         'menu_icon'   => 'dashicons-art',
         'supports'      => ['title', 'editor', 'thumbnail', 'excerpt'],
         'labels'        => $tab_labels,
      ]
   );
   register_taxonomy('produit-categorie', 'produit', ['hierarchical' => true ]);
     register_taxonomy('produit-etiquette', 'produit', ['hierarchical' => false ]);
}
add_action('init', 'my_produit_custom_post'); 
  // ------------------------------------------------ 