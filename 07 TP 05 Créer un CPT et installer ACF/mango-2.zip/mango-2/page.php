<p> modele différent pour page ....</p>
<?php  get_header();   ?>
<p> modele différent pour page ....</p>
<?php
while(have_posts()):
 the_post();
 ?>
   <h1><?php the_title() ?></h1>
   <p><?php the_content() ?></p>
 <?php
endwhile;
   get_footer(); 
 ?>