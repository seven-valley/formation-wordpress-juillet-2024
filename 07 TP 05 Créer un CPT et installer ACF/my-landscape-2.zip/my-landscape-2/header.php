<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title><?php
            wp_title('|', 'true', 'right');
            bloginfo('name');
            ?></title>
    <?php
    $theme_url = get_stylesheet_directory_uri();
    ?>
    <link rel="stylesheet" href="<?= $theme_url ?>/style.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <?php wp_head() ?>
</head>

<body>
    <!-- Responsive navbar-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container px-5">
            <a class="navbar-brand" href="<?= get_home_url() ?>"><img src="<?= get_site_icon_url(50) ?>" width="50"> Le Veilleur de nuit</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <?php

                wp_nav_menu([
                    "theme_location" =>"menu_haut",
                    "menu_class" =>"navbar-nav ms-auto mb-2 mb-lg-0",
                    "container" =>false,

                ]);
                ?>
                <!-- <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?= get_home_url() ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= get_permalink(10) ?>">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= get_permalink(32) ?>">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= get_permalink(12) ?>">Services</a></li>
                </ul> -->
            </div>
        </div>
    </nav>