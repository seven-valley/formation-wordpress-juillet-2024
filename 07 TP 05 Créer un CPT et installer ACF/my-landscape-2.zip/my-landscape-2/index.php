<?php get_header() ?>

<?php
$theme_url = get_stylesheet_directory_uri();
?>
<!-- Page Content-->
<div class="container px-4 px-lg-5">
    <!-- Heading Row-->
    <div class="row gx-4 gx-lg-5 align-items-center my-5">
        <div class="col-lg-7"><img class="img-fluid rounded mb-4 mb-lg-0" src="<?= $theme_url ?>/img/popcorn.jpg" alt="Pop corn" /></div>
        <div class="col-lg-5">
            <?php
            $query = new WP_Query([
                "post_type"  => "page",
                "p"  => 8,


            ]);
            if ($query->have_posts()) // si il y a des résultats dans la pile 
            {
                while ($query->have_posts()) {
                    $query->the_post(); // enlever le résultat de la pile 
            ?>
                    <h1 class="font-weight-light"><?php the_title() ?></h1>
                    <p><?php the_content() ?></p>
            <?php

                }
            }
            ?>



        </div>
    </div>
    <!-- Call to Action-->
    <div class="card text-white bg-secondary my-5 py-4 text-center">
        <div class="card-body">
            <p class="text-white m-0 h3"><?= get_bloginfo('description') ?></p>
        </div>
    </div>
    <!-- Content Row-->
    <div class="row gx-4 gx-lg-5">
        <?php
        $query = new WP_Query([
            "post_type"  => "post",
            "posts_per_page" => 3,
            "orderby"  => "publish_date",
            "order"  => "DESC" // DESC
        ]);
        if ($query->have_posts()) : // si il y a des résultats dans la pile 

            while ($query->have_posts()) :

                $query->the_post(); // enlever le résultat de la pile 
        ?>
                <!-- partie cards -->
                <div class="col-md-4 mb-5">
                    <div class="card h-100">
                        <div class="card-body">
                            <a href="<?php the_permalink() ?>">
                                <?php the_post_thumbnail('medium', ['class' => 'card-img-top']); ?>
                            </a>
                            <h2 class="card-title"><?php the_title() ?></h2>
                            <p class="card-text"><?php the_excerpt() ?></p>
                        </div>
                        <div class="card-footer"><a href="<?php the_permalink() ?>" class="btn btn-primary">SEE MORE</a></div>
                    </div>
                </div>
                <!-- partie cards -->
        <?php

            endwhile;
        endif;
        ?>
    </div>
</div>
<?php get_footer() ?>