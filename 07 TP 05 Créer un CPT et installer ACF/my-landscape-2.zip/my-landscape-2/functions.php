<?php
// ------------------------------------------------ 
// 1 – Les Constantes 
// -----------------------------------------------
define('THEMEROOT', get_stylesheet_directory_uri());
define('IMG', THEMEROOT . '/img');
define('JS', THEMEROOT . '/js');
define('CSS', THEMEROOT . '/css');
// ----------------------------------------------

// ------------------------------------------------------- 
// 2 & 3 – Activer les images mise en avant ET les menus
// ------------------------------------------------------
function my_theme_setup()
{
    add_theme_support('post-thumbnails'); // img mise en avant
    register_nav_menus([
        // ['identifiant' => 'Nom dans le Back Office Wordpress' ]
        'menu_haut' => 'Menu Haut de Page',
        'menu_bas'  => 'Menu Bas de Page'
    ]);
}
add_action('after_setup_theme', 'my_theme_setup'); // le crochet 
  // ------------------------------------------------ 

  //------------------------------------------------------
 // 4 . Ajouter les class css du menu
 //------------------------------------------------------- 
 
 function my_filter_a($attributes){ // <ul><li><a class="nav-link" …>
    $attributes["class"] = "nav-link"; 
    return $attributes; 
 } 
 add_filter('nav_menu_link_attributes','my_filter_a');
 
 
 function my_filter_li($classes){ // <ul><li class="my-li active"> 
    $classes[] = "nav-item"; 
    // si cette classe : 'curent-menu-item' est présente j’ajoute active 
    if (in_array('current-menu-item',$classes)){ 
      $classes[] = "active"; 
    } 
    return $classes; 
 } 
 add_filter( 'nav_menu_css_class','my_filter_li'); 